import './bootstrap';
import 'laravel-datatables-vite';
import './validations';
import './alerts';
import './filters';
import './autocomplete';

import.meta.glob([
    '../images/**',
]);