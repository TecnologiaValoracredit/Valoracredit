/** 
 * 
 * Widget Activity Five
 * 
**/

window.addEventListener("load", function(){
    try {
  
      /*
          =============================================
              Perfect Scrollbar | Notifications
          =============================================
      */
      const ps = new PerfectScrollbar(document.querySelector('.mt-container'));
  
    } catch(e) {
      // statements
      console.log(e);
    }
})