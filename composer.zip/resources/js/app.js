import './bootstrap';
import 'laravel-datatables-vite';
import './validations';
import './alerts';
import './filters';

import.meta.glob([
    '../images/**',
]);